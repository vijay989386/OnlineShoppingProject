package project;
import java.util.*;
import java.io.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;  


public class validation {
	public static void main(String[] args) {	    
	    
	     
	}
	  // method check if string is null or empty
	  public static String isNullEmpty(String message) {
	    // check if string is null
	    if (message == null || message.isEmpty()) {
	      return "NULL";
	    }
	    else {
	      return "neither NULL nor EMPTY";
	    }
	  }

///////////////////////////////////////////////////// GETDATE TIME ///////////////////////////
	  
	  public static String  CurrentDateTime() {
		  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		   LocalDateTime now = LocalDateTime.now();
		   return (dtf.format(now));
	}

}



 