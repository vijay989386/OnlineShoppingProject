package project;

import java.sql.*;

public class vijayConnection {

	public static Connection getCon() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","");
			return conn;
		}catch(Exception e){
			System.out.println(e);
			return null;
		}
		
	}

	
}

